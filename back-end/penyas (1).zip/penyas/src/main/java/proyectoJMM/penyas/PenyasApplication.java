package proyectoJMM.penyas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PenyasApplication {

	public static void main(String[] args) {
		SpringApplication.run(PenyasApplication.class, args);
	}

}
