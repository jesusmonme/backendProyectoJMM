package proyectoJMM.penyas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PenyasApplicationTests {

	@Test
	void contextLoads() {
	}

}
